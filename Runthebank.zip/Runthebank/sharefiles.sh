curl -X POST \
  https://api.box.com/2.0/collaborations/ \
  -H 'Authorization: Bearer HY8QCYC8UTZ6H2qe2YwIFBDqY7HveBj7' \
  -H 'Postman-Token: c21512f1-5039-4382-a8ad-a473cd549507' \
  -H 'cache-control: no-cache' \
  -d '{"item": { "id": "439898724674", "type": "file"}, "accessible_by": { "login": "jmahedy+av@box.com"}, "role": "Viewer"}'

  curl -X POST \
    https://api.box.com/2.0/collaborations/ \
    -H 'Authorization: Bearer HY8QCYC8UTZ6H2qe2YwIFBDqY7HveBj7' \
    -H 'Postman-Token: c21512f1-5039-4382-a8ad-a473cd549507' \
    -H 'cache-control: no-cache' \
    -d '{"item": { "id": "439898826557", "type": "file"}, "accessible_by": { "login": "jmahedy+av@box.com"}, "role": "Viewer"}'

  curl -X POST \
      https://api.box.com/2.0/collaborations/ \
      -H 'Authorization: Bearer HY8QCYC8UTZ6H2qe2YwIFBDqY7HveBj7' \
      -H 'Postman-Token: c21512f1-5039-4382-a8ad-a473cd549507' \
      -H 'cache-control: no-cache' \
      -d '{"item": { "id": "439898991335", "type": "file"}, "accessible_by": { "login": "jmahedy+av@box.com"}, "role": "Viewer"}'

  curl -X POST \
          https://api.box.com/2.0/collaborations/ \
          -H 'Authorization: Bearer HY8QCYC8UTZ6H2qe2YwIFBDqY7HveBj7' \
          -H 'Postman-Token: c21512f1-5039-4382-a8ad-a473cd549507' \
          -H 'cache-control: no-cache' \
          -d '{"item": { "id": "439890836454", "type": "file"}, "accessible_by": { "login": "jmahedy+av@box.com"}, "role": "Viewer"}'

  curl -X POST \
      https://api.box.com/2.0/collaborations/ \
          -H 'Authorization: Bearer HY8QCYC8UTZ6H2qe2YwIFBDqY7HveBj7' \
          -H 'Postman-Token: c21512f1-5039-4382-a8ad-a473cd549507' \
          -H 'cache-control: no-cache' \
          -d '{"item": { "id": "440611867646", "type": "file"}, "accessible_by": { "login": "jmahedy+av@box.com"}, "role": "Viewer"}'
